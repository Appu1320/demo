a=int(input('enter a number'))
b=int(input('enter a number'))
def sum():
    print(a+b)
def mul():
    print(a*b)
def div():
    print(a/b)
def sub():
    print(a-b)
