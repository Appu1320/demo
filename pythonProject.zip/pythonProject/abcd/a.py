#def display():
# print('hello')
'''l=["apple","orange","kiwi"]
for i in l:
   print(i,end=' ')
x= "ammu"
y="hi"
print(x.join(y))'''

'''x=input('enter the string')
l=[]
for i in x:
    if i=='a'or i=='e'or i=='i' or i=='o'or i=='u':
        l.append(i)
print(l)'''
student={"name":{"aisha":40,"anu":20,"ammu":30}}
print(student["name"]["anu"])





