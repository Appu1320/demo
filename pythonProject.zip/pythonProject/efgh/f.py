#from abcd import b
#b.greeting('anu')
import abcd.b
abcd.b.greeting('anu')