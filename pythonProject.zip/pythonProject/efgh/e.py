from abcd import a
a.display()