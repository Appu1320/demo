from abcd import c
c.sum()
c.mul()
c.div()
c.sub()
